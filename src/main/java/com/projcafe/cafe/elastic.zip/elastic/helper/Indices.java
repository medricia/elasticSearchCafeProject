package com.projcafe.cafe.elastic.helper;

public final class Indices {
	public static final String PERSON_INDEX = "person";
}
